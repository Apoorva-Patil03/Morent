-- DropIndex
DROP INDEX "Rental_carId_key";
