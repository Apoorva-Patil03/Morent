import Notfound from '@/components/NotFound/NotFound';

const NotFound = () => {
  return <Notfound />;
};

export default NotFound;
