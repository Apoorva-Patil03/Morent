'use client';
const Error = () => {
  return <div>error</div>;
};


export default Error;
